# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['connectext']

package_data = \
{'': ['*']}

install_requires = \
['connect-extension-runner>=2.2,<3.0']

entry_points = \
{'connect.eaas.ext': ['extension = connectext.extension:E2EExtension']}

setup_kwargs = {
    'name': 'eaas-extension-e2e',
    'version': '1.0.0',
    'description': 'Extension capabilities description',
    'long_description': '# Welcome to EaaS Extension e2e !\n\n\n## License\n\n**EaaS Extension e2e** is licensed under the *Apache Software License 2.0* license.\n',
    'author': 'Globex Corporation',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
